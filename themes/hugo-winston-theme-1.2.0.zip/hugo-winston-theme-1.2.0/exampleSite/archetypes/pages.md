---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
image: images/writer.jpeg
menu:
  main:
    name: "About"
---
